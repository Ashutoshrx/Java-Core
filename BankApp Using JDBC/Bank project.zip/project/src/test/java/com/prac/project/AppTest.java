package com.prac.project;

/**
 * Unit test for simple App.
 */
public class AppTest{
   
}
